package com.vxedition.editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

class MainActivity : Activity() {
    private var videoView: VideoView? = null

    companion object {
        private const val REQUEST_PICK_VIDEO = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 5, 5)
        window.navigationBarColor = android.graphics.Color.rgb(5, 5, 5)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 18)
            setBackgroundColor(0xFF050505.toInt())
        }

        val brand = TextView(this).apply {
            text = "VX EDITION"
            textSize = 27f
            setTextColor(0xFFFF2020.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        page.addView(brand, LinearLayout.LayoutParams(-1, 54))

        val subtitle = TextView(this).apply {
            text = "EDITOR DE VÍDEO"
            textSize = 11f
            letterSpacing = 0.22f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, LinearLayout.LayoutParams(-1, 28))

        videoView = VideoView(this).apply {
            setBackgroundColor(0xFF171717.toInt())
        }
        val previewParams = LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(0, 20, 0, 16)
        }
        page.addView(videoView, previewParams)

        val importButton = makeButton("＋  IMPORTAR VÍDEO", true)
        importButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, REQUEST_PICK_VIDEO)
        }
        page.addView(importButton)

        val timeline = TextView(this).apply {
            text = "LINHA DO TEMPO\n────────────────────────────\nSeu clipe aparecerá aqui"
            textSize = 13f
            setTextColor(0xFFBBBBBB.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 20)
            setBackgroundColor(0xFF151515.toInt())
        }
        val timelineParams = LinearLayout.LayoutParams(-1, 92).apply {
            setMargins(0, 12, 0, 12)
        }
        page.addView(timeline, timelineParams)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Cortar", "Áudio", "Texto").forEach { label ->
            val button = makeButton(label)
            row1.addView(button, LinearLayout.LayoutParams(0, 52, 1f).apply {
                setMargins(3, 0, 3, 0)
            })
            button.setOnClickListener { toast("A ferramenta $label ainda não está implementada.") }
        }
        page.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Reverse", "Velocidade", "Efeitos").forEach { label ->
            val button = makeButton(label)
            row2.addView(button, LinearLayout.LayoutParams(0, 52, 1f).apply {
                setMargins(3, 8, 3, 0)
            })
            button.setOnClickListener { toast("A ferramenta $label ainda não está implementada.") }
        }
        page.addView(row2)

        val exportButton = makeButton("EXPORTAR", true)
        val exportParams = LinearLayout.LayoutParams(-1, 54).apply {
            setMargins(0, 14, 0, 0)
        }
        page.addView(exportButton, exportParams)
        exportButton.setOnClickListener {
            toast("A exportação será adicionada em uma próxima versão.")
        }

        setContentView(page)
    }

    private fun makeButton(label: String, primary: Boolean = false): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (primary) 0xFFB5121B.toInt() else 0xFF202020.toInt()
        )
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_VIDEO || resultCode != RESULT_OK) return

        val resultIntent = data ?: return
        val uri = resultIntent.data ?: return

        val permissionFlags = resultIntent.flags and (
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        if (permissionFlags != 0) {
            try {
                contentResolver.takePersistableUriPermission(uri, permissionFlags)
            } catch (_: SecurityException) {
                // A prévia ainda pode funcionar com a permissão temporária do seletor.
            } catch (_: IllegalArgumentException) {
                // Alguns provedores não oferecem permissão persistente.
            }
        }

        videoView?.apply {
            setVideoURI(uri)
            setOnPreparedListener { mediaPlayer ->
                mediaPlayer.isLooping = true
                start()
            }
        }
        toast("Vídeo carregado!")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
