# VX EDITION — base Android inicial

Projeto Android nativo com interface preta/vermelha e uma prévia de vídeo.

## O que esta versão faz
- Abre como aplicativo Android.
- Permite escolher um vídeo pelo seletor de arquivos do Android.
- Reproduz o vídeo escolhido na tela de prévia.

## O que ainda não faz
Corte real, trilhas de áudio, textos sobre o vídeo, camadas, reverse, controle de velocidade, efeitos, filtros e exportação ainda não foram implementados. Os botões dessas ferramentas avisam que elas ainda estão em desenvolvimento. Esta base não é ainda um editor completo.

## Versões usadas
- Android Gradle Plugin: 8.7.3
- Kotlin Gradle Plugin: 2.0.21
- Gradle: 8.9
- Android SDK: API 35
- Java: 17

## GitHub Actions
Use o arquivo `build.yml` fornecido separadamente e coloque-o no repositório neste caminho: `.github/workflows/build.yml`.
Depois, envie este ZIP para a raiz do repositório com o nome exato `VX_EDITION_Projeto_GitHub_Actions_REVISADO.zip`.
O workflow extrai o projeto, compila o APK de depuração e publica o resultado em Artifacts.
